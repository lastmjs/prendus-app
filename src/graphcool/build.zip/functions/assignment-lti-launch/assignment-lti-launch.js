"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = y[op[0] & 2 ? "return" : op[0] ? "throw" : "next"]) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [0, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var _this = this;
Object.defineProperty(exports, "__esModule", { value: true });
var fromEvent = require('graphcool-lib').fromEvent;
var JWT = require('jsonwebtoken');
var lti = require('ims-lti');
exports.default = function (event) { return __awaiter(_this, void 0, void 0, function () {
    var body, graphcool, api, ltiUserId, assignmentId, courseId, assignmentType, lisPersonContactEmailPrimary, key, secret, ltiProvider, ltiSessionId, ltiSessionIdJWT, ltiSessionIdJWTCookie, ltiUser, clientRedirectUrl, clientRedirectUrlCookie, _a, error_1;
    return __generator(this, function (_b) {
        switch (_b.label) {
            case 0:
                if (!event.context.graphcool.rootToken) {
                    console.log('Please provide a valid root token!');
                    return [2 /*return*/, { error: 'assignment-lti-launch not configured correctly.' }];
                }
                _b.label = 1;
            case 1:
                _b.trys.push([1, 7, , 8]);
                body = parseUrlEncodedBody(event.data.requestBody);
                graphcool = fromEvent(event);
                api = graphcool.api('simple/v1');
                ltiUserId = body.user_id;
                assignmentId = event.data.assignmentId;
                return [4 /*yield*/, getCourseId(api, assignmentId)];
            case 2:
                courseId = _b.sent();
                assignmentType = event.data.assignmentType;
                lisPersonContactEmailPrimary = body.lis_person_contact_email_primary;
                key = body.oauth_consumer_key;
                secret = getLTISecret(key);
                return [4 /*yield*/, validateLTIRequest(key, secret, {
                        body: body,
                        protocol: 'https',
                        url: "/lti" + event.data.path.replace('{assignmentid}', assignmentId).replace('{assignmenttype}', assignmentType),
                        headers: {
                            host: 'api.prendus.com'
                        },
                        method: event.data.method
                    })];
            case 3:
                ltiProvider = _b.sent();
                return [4 /*yield*/, createLTISession(api, ltiProvider, ltiUserId)];
            case 4:
                ltiSessionId = _b.sent();
                ltiSessionIdJWT = JWT.sign({
                    ltiSessionId: ltiSessionId
                }, process.env.PRENDUS_JWT_SECRET);
                ltiSessionIdJWTCookie = "ltiSessionIdJWT=" + ltiSessionIdJWT + "; Domain=" + process.env.PRENDUS_CLIENT_DOMAIN + "; Path=/";
                return [4 /*yield*/, getLTIUser(api, ltiUserId)];
            case 5:
                ltiUser = _b.sent();
                clientRedirectUrl = "assignment/" + assignmentId + "/" + assignmentType.toLowerCase();
                clientRedirectUrlCookie = "redirectUrl=" + clientRedirectUrl + "; Domain=" + process.env.PRENDUS_CLIENT_DOMAIN + "; Path=/";
                _a = {};
                return [4 /*yield*/, generateReturnValues(api, ltiUser, courseId, ltiSessionIdJWTCookie, clientRedirectUrlCookie, assignmentId, assignmentType, ltiUserId, lisPersonContactEmailPrimary, process.env.PRENDUS_JWT_SECRET)];
            case 6: return [2 /*return*/, (_a.data = _b.sent(),
                    _a)];
            case 7:
                error_1 = _b.sent();
                console.log(error_1);
                return [2 /*return*/, {
                        error: 'An error occurred'
                    }];
            case 8: return [2 /*return*/];
        }
    });
}); };
function createLTISession(api, ltiProvider, ltiUserId) {
    return __awaiter(this, void 0, void 0, function () {
        var outcomeServiceJSON, data;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    outcomeServiceJSON = jsonifyOutcomeService(ltiProvider.outcome_service);
                    return [4 /*yield*/, api.request("\n        mutation($ltiUserId: String!, $serializedOutcomeService: Json!) {\n            createLTISession(\n                ltiUserId: $ltiUserId\n                serializedOutcomeService: $serializedOutcomeService\n            ) {\n                id\n            }\n        }\n    ", {
                            ltiUserId: ltiUserId,
                            serializedOutcomeService: outcomeServiceJSON
                        })];
                case 1:
                    data = _a.sent();
                    return [2 /*return*/, data.createLTISession.id];
            }
        });
    });
}
function jsonifyOutcomeService(outcomeService) {
    return {
        cert_authority: outcomeService.cert_authority,
        consumer_key: outcomeService.consumer_key,
        consumer_secret: outcomeService.consumer_secret,
        language: outcomeService.language,
        result_data_types: outcomeService.result_data_types,
        service_url: outcomeService.service_url,
        service_url_oauth: outcomeService.service_url_oauth,
        service_url_parts: outcomeService.service_url_parts,
        signer: null,
        source_did: outcomeService.source_did,
        send_replace_result: null,
        supports_result_data: null,
        send_read_result: null,
        send_delete_result: null,
        send_replace_result_with_text: null,
        send_replace_result_with_url: null
    };
}
function getCourseId(api, assignmentId) {
    return __awaiter(this, void 0, void 0, function () {
        var data;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, api.request("\n      query {\n          Assignment(\n              id: \"" + assignmentId + "\"\n          ) {\n              course {\n                  id\n              }\n          }\n      }\n    ")];
                case 1:
                    data = _a.sent();
                    return [2 /*return*/, data.Assignment.course.id];
            }
        });
    });
}
function parseUrlEncodedBody(rawBody) {
    return rawBody
        .split('&')
        .map(function (x) { return x.split('='); })
        .reduce(function (result, x) {
        var key = decodeURIComponent(x[0]);
        var value = decodeURIComponent(x[1].replace(/\+/g, '%20'));
        return Object.assign({}, result, (_a = {},
            _a[key] = value,
            _a));
        var _a;
    }, {});
}
function generateReturnValues(api, ltiUser, courseId, ltiSessionIdJWTCookie, clientRedirectUrlCookie, assignmentId, assignmentType, ltiUserId, lisPersonContactEmailPrimary, rootToken) {
    return __awaiter(this, void 0, void 0, function () {
        var ltiJWT;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    if (!ltiUser) return [3 /*break*/, 3];
                    return [4 /*yield*/, enrollUserOnCourse(api, ltiUser.user.id, courseId)];
                case 1:
                    _a.sent();
                    return [4 /*yield*/, payForCourseIfFree(api, ltiUser.user.id, courseId)];
                case 2:
                    _a.sent();
                    //TODO we are only adding the cookie syntax in here until a more elegant solution is provided by AWS API Gateway or graph.cool (we'll be dropping AWS API Gateway as soon as graph.cool supports setting headers and gives full access to the response body)
                    return [2 /*return*/, {
                            ltiSessionIdJWTCookie: ltiSessionIdJWTCookie,
                            clientRedirectUrlCookie: clientRedirectUrlCookie,
                            serverRedirectUrl: process.env.PRENDUS_CLIENT_ORIGIN + "/assignment/" + assignmentId + "/" + assignmentType.toLowerCase()
                        }];
                case 3:
                    ltiJWT = JWT.sign({
                        assignmentId: assignmentId,
                        ltiUserId: ltiUserId,
                        lisPersonContactEmailPrimary: lisPersonContactEmailPrimary
                    }, rootToken);
                    //TODO we are only adding the cookie syntax in here until a more elegant solution is provided by AWS API Gateway or graph.cool (we'll be dropping AWS API Gateway as soon as graph.cool supports setting headers and gives full access to the response body)
                    return [2 /*return*/, {
                            ltiJWTCookie: "ltiJWT=" + ltiJWT + "; Domain=" + process.env.PRENDUS_CLIENT_DOMAIN + "; Path=/",
                            ltiSessionIdJWTCookie: ltiSessionIdJWTCookie,
                            clientRedirectUrlCookie: clientRedirectUrlCookie,
                            serverRedirectUrl: process.env.PRENDUS_CLIENT_ORIGIN + "/authenticate"
                        }];
            }
        });
    });
}
function getLTISecret(key) {
    //TODO eventually this will retrieve from the databases the LTI secret associated with the assignment/course
    return process.env.PRENDUS_LTI_SECRET;
}
function validateLTIRequest(key, secret, req) {
    return __awaiter(this, void 0, void 0, function () {
        return __generator(this, function (_a) {
            return [2 /*return*/, new Promise(function (resolve, reject) {
                    var ltiProvider = new lti.Provider(key, secret);
                    ltiProvider.valid_request(req, function (error, isValid) {
                        if (isValid) {
                            resolve(ltiProvider);
                        }
                        else if (error) {
                            reject(error);
                        }
                        else {
                            reject('LTI request not valid');
                        }
                    });
                })];
        });
    });
}
function getLTIUser(api, ltiUserId) {
    return __awaiter(this, void 0, void 0, function () {
        var data;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, api.request("\n        query {\n            ltiUser: LTIUser(ltiUserId: \"" + ltiUserId + "\") {\n                user {\n                    id\n                }\n            }\n        }\n    ")];
                case 1:
                    data = _a.sent();
                    return [2 /*return*/, data.ltiUser];
            }
        });
    });
}
function payForCourseIfFree(api, userId, courseId) {
    return __awaiter(this, void 0, void 0, function () {
        var data, price, _a;
        return __generator(this, function (_b) {
            switch (_b.label) {
                case 0: return [4 /*yield*/, api.request("\n      query {\n          Course(\n              id: \"" + courseId + "\"\n          ) {\n              price\n          }\n      }\n    ")];
                case 1:
                    data = _b.sent();
                    price = data.Course.price;
                    if (!(price === 0)) return [3 /*break*/, 3];
                    return [4 /*yield*/, payForCourseIfNoPurchaseExists(api, userId, courseId)];
                case 2:
                    _a = _b.sent();
                    return [3 /*break*/, 4];
                case 3:
                    _a = -1;
                    _b.label = 4;
                case 4: return [2 /*return*/, _a];
            }
        });
    });
}
function payForCourseIfNoPurchaseExists(api, userId, courseId) {
    return __awaiter(this, void 0, void 0, function () {
        var data;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, api.request("\n        query {\n            allPurchases(filter: {\n                user: {\n                    id: \"" + userId + "\"\n                }\n                course: {\n                    id: \"" + courseId + "\"\n                }\n            }) {\n                id\n            }\n        }\n    ")];
                case 1:
                    data = _a.sent();
                    return [2 /*return*/, data.allPurchases.length === 0 ? payForCourse(api, userId, courseId) : -1];
            }
        });
    });
}
function payForCourse(api, userId, courseId) {
    return __awaiter(this, void 0, void 0, function () {
        var data;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, api.request("\n        mutation {\n            createPurchase(\n                   userId: \"" + userId + "\"\n                   amount: 0\n                   courseId: \"" + courseId + "\"\n                   stripeTokenId: \"there is no stripeTokenId for a free course\"\n            ) {\n                course {\n                    price\n                }\n            }\n        }\n    ")];
                case 1:
                    data = _a.sent();
                    return [2 /*return*/, data.createPurchase.course.price];
            }
        });
    });
}
function enrollUserOnCourse(api, userId, courseId) {
    return __awaiter(this, void 0, void 0, function () {
        var data;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, api.request("\n        mutation {\n            addToStudentsAndCourses(\n                enrolledCoursesCourseId: \"" + courseId + "\"\n                enrolledStudentsUserId: \"" + userId + "\"\n            ) {\n                enrolledStudentsUser {\n                    id\n                }\n                enrolledCoursesCourse {\n                    id\n                }\n            }\n        }\n    ")];
                case 1:
                    data = _a.sent();
                    return [2 /*return*/, data.addToStudentsAndCourses.enrolledStudentsUser.id];
            }
        });
    });
}
